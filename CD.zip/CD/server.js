const http = require("http");
const { create, all } = require("mathjs");

const math = create(all);

// Function to wrap trig functions for degree/radian conversion in mathjs expression string
function convertDegreesToRadians(expr) {
  // Convert trig functions input degrees -> radians
  expr = expr.replace(/sin\(/g, 'sin((pi / 180) * ');
  expr = expr.replace(/cos\(/g, 'cos((pi / 180) * ');
  expr = expr.replace(/tan\(/g, 'tan((pi / 180) * ');

  // Convert inverse trig functions output radians -> degrees
  expr = expr.replace(/asin\(/g, '(180 / pi) * asin(');
  expr = expr.replace(/acos\(/g, '(180 / pi) * acos(');
  expr = expr.replace(/atan\(/g, '(180 / pi) * atan(');

  return expr;
}

http.createServer((req, res) => {
  // Allow CORS for local development
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  if (req.method === "POST") {
    let body = "";

    req.on("data", chunk => body += chunk);

    req.on("end", () => {
      try {
        // Replace ^ with ** for exponentiation in mathjs
        let expr = body.replace(/\^/g, '**');
        // Convert degrees to radians for trig, and radians to degrees for inverse trig
        expr = convertDegreesToRadians(expr);
        // Evaluate the expression using mathjs
        let result = math.evaluate(expr);

        // Threshold for floating point near-zero cleanup
        const EPSILON = 1e-14;
        if (typeof result === "number" && Math.abs(result) < EPSILON) {
          result = 0;
        }

        res.end(result.toString());
      } catch (error) {
        res.end("Error: Invalid Expression");
      }
    });
  } else {
    res.writeHead(405, {'Content-Type': 'text/plain'});
    res.end('Method Not Allowed');
  }
}).listen(3000);

console.log("Server running at http://localhost:3000");
